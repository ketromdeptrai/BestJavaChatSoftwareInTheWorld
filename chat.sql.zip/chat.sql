--
-- Database: `chat`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_conversation`
--

CREATE TABLE `tbl_conversation` (
  `id` int(10) UNSIGNED NOT NULL,
  `userSend` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userReceive` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `seen` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_conversation`
--

INSERT INTO `tbl_conversation` (`id`, `userSend`, `userReceive`, `message`, `time`, `seen`) VALUES
(137, 'ad', '| ad admin |', '|null', '2016-05-03 20:34:08', 0),
(138, 'ad', '| ad ketromdeptrai |', '|null', '2016-05-03 20:34:34', 0),
(139, 'ad', '| ad ketromdeptrai |', 'hello', '2016-05-03 20:34:39', 0),
(140, 'ad', '| ad ketromdeptrai |', 'can you hear me', '2016-05-03 20:34:49', 0),
(141, 'ad', '| ad ketromdeptrai |', ':3', '2016-05-03 20:34:53', 0),
(142, 'ketromdeptrai', '| ad ketromdeptrai |', 'yes, I can', '2016-05-03 20:35:15', 0),
(143, 'ketromdeptrai', '| ad ketromdeptrai |', ':*', '2016-05-03 20:35:18', 0),
(144, 'ketromdeptrai', '| ad ketromdeptrai |', '<file>main.h', '2016-05-03 20:37:23', 0),
(145, 'admin', '| ad admin |', 'vcl', '2016-05-09 21:17:50', 0),
(146, 'admin', '| ad admin |', '<file>Ha Zem001.jpg', '2016-05-09 21:18:16', 0),
(147, 'ad', '| ad ketromdeptrai admin |', '|null|', '2016-05-09 21:54:06', 0),
(148, 'ad', '| ad ketromdeptrai admin |', 'abc', '2016-05-09 21:54:09', 0),
(149, 'ad', '| ad ketromdeptrai admin |', 'xyz', '2016-05-09 21:54:13', 0),
(150, 'ketromdeptrai', '| ad ketromdeptrai admin |', 'hello', '2016-05-09 21:54:51', 0),
(151, 'ketromdeptrai', '| ad ketromdeptrai admin |', ':v', '2016-05-09 21:54:53', 0),
(152, 'ketromdeptrai', '| ad ketromdeptrai admin |', ':*', '2016-05-09 21:54:55', 0),
(154, 'admin', '| ad ketromdeptrai admin |', 'hello cac anh em', '2016-05-09 21:55:44', 0),
(155, 'ketromdeptrai', '| ad ketromdeptrai admin |', '<file>altiumdesigner.pdf', '2016-05-09 21:56:27', 0),
(156, 'admin', '| ad admin |', 'jasdasd', '2017-05-06 14:06:36', 0),
(157, 'admin', '| ad admin |', 'asfafaerfaf', '2017-05-06 14:07:18', 0),
(158, 'admin', '| ad admin |', 'asdfasdfawdfaoij', '2017-05-06 14:07:20', 0),
(159, 'admin', '| ad admin |', 'adasdaiusdh', '2017-05-06 14:07:25', 0),
(160, 'ad', '| ad admin |', 'WDF', '2017-05-06 14:07:27', 0),
(161, 'ad', '| ad admin |', 'awfwaefwe', '2017-05-06 14:07:30', 0),
(162, 'ad', '| ad admin |', 'sdfaofih', '2017-05-06 14:07:33', 0),
(163, 'admin', '| ad admin |', 'fwaOeifiwoea', '2017-05-06 14:07:35', 0),
(164, 'admin', '| ad admin |', 'fsdfiljwaiodsf', '2017-05-06 14:07:38', 0),
(165, 'admin', '| ad admin |', 'ASdfqdfw', '2017-05-06 14:07:42', 0),
(166, 'ad', '| ad admin |', 'waegweag', '2017-05-06 14:07:44', 0),
(167, 'admin', '| ad admin |', 'tghk', '2017-05-06 14:07:46', 0),
(168, 'ad', '| ad admin |', 'rfjhf', '2017-05-06 14:07:48', 0),
(169, 'ad', '| ad admin |', '|null|', '2017-05-06 14:28:03', 0),
(170, 'ad', '| ad admin |', 'heehe', '2017-05-06 14:57:25', 0),
(171, 'ad', '| ad admin |', '<file>game.ico', '2017-05-06 14:58:02', 0),
(172, 'ad', '| ad admin |', ':)', '2017-05-06 15:14:34', 0),
(173, 'ad', '| ad admin |', ':P', '2017-05-06 15:14:38', 0),
(174, 'ad', '| ad admin |', ':v', '2017-05-06 15:14:41', 0),
(175, 'ad', '| ad admin |', ':))', '2017-05-06 15:14:45', 0),
(176, 'ad', '| ad admin |', ':X', '2017-05-06 15:14:49', 0),
(177, 'ad', '| ad admin |', ':*', '2017-05-06 15:15:00', 0),
(178, 'ad', '| ad dung |', '|null|', '2017-05-06 18:30:53', 0),
(179, 'dung', '| ad dung |', 'ngon :)))', '2017-05-06 18:31:00', 0),
(180, 'ad', '| ad dung |', 'con m? mày', '2017-05-06 18:31:00', 0),
(181, 'ad', '| ad dung |', '??t', '2017-05-06 18:31:04', 0),
(182, 'dung', '| ad dung |', ':v', '2017-05-06 18:31:05', 0),
(183, 'ad', '| ad dung |', 'loi font tieng viet', '2017-05-06 18:31:09', 0),
(184, 'ad', '| ad dung |', '=))))', '2017-05-06 18:31:12', 0),
(185, 'ad', '| ad dung |', 'gg', '2017-05-06 18:31:14', 0),
(186, 'dung', '| ad dung |', 'Nát :v', '2017-05-06 18:31:15', 0),
(187, 'ad', '| ad dung |', 'vc', '2017-05-06 18:31:18', 0),
(188, 'ad', '| ad dung |', 'sao k loi the', '2017-05-06 18:31:23', 0),
(189, 'dung', '| ad dung |', '?ê m? Phú :v', '2017-05-06 18:31:27', 0),
(190, 'dung', '| ad dung |', 'V?n l?i mà', '2017-05-06 18:31:34', 0),
(191, 'ad', '| ad dung |', 'dau xanh', '2017-05-06 18:31:39', 0),
(192, 'dung', '| ad dung |', ':v', '2017-05-06 18:31:43', 0),
(193, 'ad', '| ad dung |', 'thoi ksao :)))', '2017-05-06 18:31:44', 0),
(194, 'ad', '| ad dung |', 'xin vcl =)))', '2017-05-06 18:31:49', 0),
(195, 'dung', '| ad dung |', 'Gui 1 file day coi', '2017-05-06 18:31:56', 0),
(196, 'ad', '| ad dung |', '<file>HUST.jpg', '2017-05-06 18:32:11', 0),
(197, 'ad', '| ad dung |', 'mut''', '2017-05-06 18:32:18', 0),
(198, 'ad', '| ad dung |', 'ok ko', '2017-05-06 18:32:36', 0),
(199, 'ad', '| ad dung |', 'logo truong', '2017-05-06 18:32:40', 0),
(200, 'dung', '| ad dung |', '? mà ubuntu nó l?u vào ch? nào nh?', '2017-05-06 18:32:43', 0),
(201, 'ad', '| ad dung |', 'cai dis', '2017-05-06 18:32:51', 0),
(202, 'ad', '| ad dung |', 'dung ubuntu a', '2017-05-06 18:32:54', 0),
(203, 'dung', '| ad dung |', 'uk :))', '2017-05-06 18:32:59', 0),
(204, 'ad', '| ad dung |', 'the thi phai sua ma nguon', '2017-05-06 18:33:01', 0),
(205, 'dung', '| ad dung |', 'thoi keme', '2017-05-06 18:33:08', 0),
(206, 'ad', '| ad dung |', 'dang de la luu vao o D', '2017-05-06 18:33:15', 0),
(207, 'dung', '| ad dung |', 'uk :))) thoi the la oke roi', '2017-05-06 18:33:28', 0),
(208, 'ad', '| ad dung |', 'vcd =)))', '2017-05-06 18:33:36', 0),
(209, 'dung', '| ad dung |', 'Hay la sua ma nguon cho chon cho luu', '2017-05-06 18:34:09', 0),
(210, 'ad', '| ad dung |', 'lai phai viet them cai JFileChooser moi', '2017-05-06 18:34:48', 0),
(211, 'ad', '| ad dung |', 'met vcl', '2017-05-06 18:34:54', 0),
(212, 'dung', '| ad dung |', 'Lieu kip k', '2017-05-06 18:34:57', 0),
(213, 'dung', '| ad dung |', 'the thoi kemee', '2017-05-06 18:35:09', 0),
(214, 'ad', '| ad dung |', 'viet thi viet dc', '2017-05-06 18:35:10', 0),
(215, 'ad', '| ad dung |', 'hoac t se tim cach', '2017-05-06 18:35:19', 0),
(216, 'ad', '| ad dung |', 'ah thoi', '2017-05-06 18:35:32', 0),
(217, 'dung', '| ad dung |', 'T2 cho xem cai qua len internet de :v', '2017-05-06 18:35:38', 0),
(218, 'ad', '| ad dung |', 'hom nao test dung windows', '2017-05-06 18:35:39', 0),
(219, 'dung', '| ad dung |', 'thay interesting day', '2017-05-06 18:35:57', 0),
(220, 'dung', '| ad dung |', '<file>D:\\HUST.jpg', '2017-05-06 18:37:35', 0),
(221, 'dung', '| ad dung |', ':))))', '2017-05-06 18:37:39', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `userName` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Thông tin về tài khoản';

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`userName`, `password`) VALUES
('|', '|'),
('ad', 'ad'),
('admin', 'admin'),
('dung', '1'),
('ketromdeptrai', '123456'),
('ketromdepzai', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_conversation`
--
ALTER TABLE `tbl_conversation`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `userSend` (`userSend`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`userName`),
  ADD UNIQUE KEY `userName` (`userName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_conversation`
--
ALTER TABLE `tbl_conversation`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=222;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_conversation`
--
ALTER TABLE `tbl_conversation`
  ADD CONSTRAINT `tbl_conversation_ibfk_1` FOREIGN KEY (`userSend`) REFERENCES `tbl_user` (`userName`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
